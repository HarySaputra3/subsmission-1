export default class AboutPresenter {
    constructor(view) {
      this.view = view;
    }
  
    init() {
      console.log("AboutPresenter initialized");
    }
  }
  